#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    db = QSqlDatabase::addDatabase("QMYSQL");
     db.setHostName("127.0.0.1");
     db.setPort(3306);
     db.setDatabaseName("test");
     db.setUserName("jathu_qt");
     db.setPassword("qt_my_boy");
     if (db.open())
     {
     qDebug() << "Connected!";
     }
     else
     {
     qDebug() << "Failed to connect.";
     }

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_loginBtn_clicked()
{
    QString username = ui->userInput->text();
    QString password = ui->passInput->text();
    qDebug() << username << password;
    QString command ="SELECT * from user WHERE username='" + username +"' AND password = '" +password+"' AND status=0";
    QSqlQuery query(db);
    if (query.exec(command)){
        if (query.size()>0){
            QMessageBox::information(this,"Login success.","you have successfully logged in!");

        }
        else{
            QMessageBox::information(this,"Login failed.","Try Again!");

        }

}
}

